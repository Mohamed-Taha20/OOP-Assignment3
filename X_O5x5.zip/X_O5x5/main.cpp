#include <iostream>
#include <map>
#include <cctype>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;


int main()
{


    return 0;
}